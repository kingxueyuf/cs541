/*
 * <AUTHOR>
 * <DATE>
 *
 * CS 441/541 : Memory Management Performance Template
 */
#include "scalarmult.h"

int main(int argc, char * argv[]) {

    // Initialize the support library
    support_init();

    // Finalize the support library
    support_finalize();

    return 0;
}
