/*
 * <AUTHOR>
 * <DATE>
 *
 * CS 441/541 : Memory Management Performance Template
 */
#include "support.h"
#include <time.h>
#include <stdlib.h>


double run_experiment_ij(mtype_t *matrix,
                         mtype_t scalar, int N);


double run_experiment_ji(mtype_t *matrix,
                         mtype_t scalar, int N);